# INSTABOT
INSTABOT es una herramienta para obtener seguidores en instagram abriendo una red en 2 plano con un agente de navegador personalizado que trabaje desde tu dispositivo en 2 plano.


### Compatibilidad 
Este script solo se ha probado en kali linux pero trabaja en todas las distros
basadas en debian y en termux.

### INSTALACION EN LINUX

```
sudo apt update
```
```
sudo apt install git
```
```
sudo apt install openssl
```
```
git clone https://github.com/bythelink89/INSTABOT.git
```
```
cd INSTABOT
```
```
bash INSTABOT.sh
```
### INSTALACION EN TERMUX
` pkg up -y`

` pkg install openssl-tool`

` pkg install curl`

` pkg install git`

` git clone https://github.com/bythelink89/INSTABOT.git`

`cd INSTABOT`

` chmod +x INSTABOT.sh`

` termux-wake-lock`

` bash INSTABOT.sh`

### CAPTURAS
![alt text](images/INSTABOT.png)
![alt text](images/INSTABOT1.png)
![alt text](images/test1.jpeg)
![alt text](images/test2.jpeg)
